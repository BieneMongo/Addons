import xbmcaddon
import xbmcgui
import xbmc

import subprocess
import sys

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
icon        = addon.getAddonInfo('icon')

profile = xbmc.translatePath(addon.getAddonInfo('profile')).decode("utf-8")
filename = profile + "update.log"

xbmcgui.Dialog().notification('Started Update', 'Updating package list', icon)

with open(filename, "w") as f:
    bashCommand = "sudo apt-get -y update"
    process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
    for line in iter(lambda: process.stdout.read(1), b''):
        sys.stdout.write(line)
        f.write(line)
        xbmcgui.Dialog().textviewer('Updating package list', str(sys.stdout.write(line)))

xbmcgui.Dialog().notification('Started Upgrade', 'Updating installed packages', icon)

bashCommand = "sudo apt-get -y dist-upgrade"
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)

xbmcgui.Dialog().notification('Cleanup', 'Deleting unused dependencies', icon)

bashCommand = "sudo apt-get -y autoclean"
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)

xbmcgui.Dialog().notification('Cleanup', 'Deleting packages not longer needed', icon)

bashCommand = "sudo apt-get -y autoclean"
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)

if xbmcgui.Dialog().yesno('Update finished', 'Do you want to reboot now?'):
    bashCommand = "sudo reboot"
    process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
