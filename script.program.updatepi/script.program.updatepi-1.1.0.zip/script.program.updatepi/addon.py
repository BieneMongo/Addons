import xbmcaddon
import xbmcgui
import xbmc

import subprocess


def writefile(file, heading, command):
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
    for line in iter(process.stdout.readline, b''):
        file.write(line.decode("iso-8859-1").encode("utf-8"))
        xbmcgui.Dialog().notification(heading, line)


addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')

reboot = addon.getSetting('auto_r')

profile = xbmc.translatePath(addon.getAddonInfo('profile')).decode("utf-8")
filename = profile + "update.log"

try:
    with open(filename, "r") as f:
        f.close()
except:
    xbmcgui.Dialog().notification('Directory not found', 'Could not find update.log')
    bashCommand = "sudo mkdir " + profile
    subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
finally:
    with open(filename, "w") as f:
        xbmcgui.Dialog().notification('Started Update', 'Updating package list', icon)
        bashCommand = "sudo apt-get -y update"

        writefile(f, 'Updating package list', bashCommand)

        xbmcgui.Dialog().notification('Started Upgrade', 'Updating installed packages', icon)
        bashCommand = "sudo apt-get -y dist-upgrade"

        writefile(f, 'Updating installed packages', bashCommand)

        xbmcgui.Dialog().notification('Cleanup', 'Deleting unused dependencies', icon)
        bashCommand = "sudo apt-get -y autoclean"

        writefile(f, 'Deleting unused dependencies', bashCommand)

        xbmcgui.Dialog().notification('Cleanup', 'Deleting packages not longer needed', icon)
        bashCommand = "sudo apt-get -y autoclean"

        writefile(f, 'Deleting packages not longer needed', bashCommand)

        if reboot:
            f.close()
            xbmcgui.Dialog().ok('Restarting', '')
            bashCommand = "sudo reboot"
            subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
            exit()

        if xbmcgui.Dialog().yesno('Update finished', 'Do you want to reboot now?'):
            f.close()
            bashCommand = "sudo reboot"
            xbmcgui.Dialog().ok('Restarting', '')
            subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
            exit()

        f.close()
