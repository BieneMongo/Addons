import xbmcaddon
import xbmcgui

import subprocess

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
icon        = addon.getAddonInfo('icon')

xbmcgui.Dialog().notification('Started Update', 'Updating package list', icon)

bashCommand = "sudo apt-get -y update"
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()

xbmcgui.Dialog().notification('Started Upgrade', 'Updating installed packages', icon)

bashCommand = "sudo apt-get -y dist-upgrade"
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()

xbmcgui.Dialog().notification('Cleanup', 'Deleting unused dependencies', icon)

bashCommand = "sudo apt-get -y autoclean"
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()

xbmcgui.Dialog().notification('Cleanup', 'Deleting packages not longer needed', icon)

bashCommand = "sudo apt-get -y autoclean"
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()

if xbmcgui.Dialog().yesno('Update finished', 'Do you want to reboot now?'):
    bashCommand = "sudo reboot"
    process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
    output, error = process.communicate()
