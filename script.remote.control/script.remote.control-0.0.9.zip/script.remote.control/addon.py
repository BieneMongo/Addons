import xbmcaddon
import xbmcgui

import subprocess

addon = xbmcaddon.Addon()
sockets = int(addon.getSetting('sockets'))

# Check if Sockets are defined
if sockets == 0:
    xbmcgui.Dialog().notification('Error: No sockets set', 'The number of sockets is not defined', xbmcgui.NOTIFICATION_ERROR)
    exit()
if sockets > 9:
    xbmcgui.Dialog().notification('Error: Too much sockets set', 'The number of sockets is not defined ' + str(sockets) + ' > 9', xbmcgui.NOTIFICATION_ERROR)
    exit()

addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')

# Code for the remote
code = addon.getSetting('code')

# Status for each socket
socketStatus = []
# Set default value to 0
currentSocket = 0
while currentSocket < sockets:
    socketStatus.append("0")
    currentSocket += 1

# Check if different status is set
try:
    # Open status file
    f = open("resources/status", "r")
    line = 0

    # read every line
    for x in f:
        # check for 0 or 1 only
        if x[3] != "0" and x[3] != "1":
            # send notification, close file, exit
            xbmcgui.Dialog().notification('Error: Wrong Status', 'Some sockets may have wrong status: ' + x, xbmcgui.NOTIFICATION_ERROR)
            f.close()
            exit()

        # write last status to local variable
        socketStatus[line] = x[3]
    f.close()

    # rewrite status file
    f = open("resources/status", "a")
    currentSocket = 0
    while currentSocket < sockets:
        f.write(str(currentSocket) + str(socketStatus[currentSocket]))
        currentSocket += 1
    f.close()

except:
    # write config
    f = open("resources/status", "a")
    currentSocket = 0
    while currentSocket < sockets:
        f.write(str(currentSocket) + str(socketStatus[currentSocket]))
        currentSocket += 1
    f.close()

finally:
    # create an socket list
    item = 1
    socketList = []
    currentSocket = 0

    #debug dialog
    xbmcgui.Dialog().notification('Test', 'Sockets: ' + str(sockets), icon)

    while currentSocket < sockets:
        if socketStatus[item-1] == 0:
            socketList.append('Socket ' + str(item) + ' on')
        if socketStatus[item-1] == 1:
            socketList.append('Socket ' + str(item) + ' off')
        item += 1
        currentSocket += 1

    #debug dialog
    xbmcgui.Dialog().notification('Test', socketList[currentSocket], icon)

    # create selection dialog
    chosen = xbmcgui.Dialog().select('Select the socket', ["0", "1", "2"])

    # send on/off codes
    if socketStatus[chosen] == 0:
        bashCommand = "sudo $HOME/utils/433Utils/RPi_utils/send" + " " + str(code) + " " + str(chosen) + " 1"
        subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
        xbmcgui.Dialog().notification('Socket ' + str(chosen) + ' on', 'Turned on socket ' + str(chosen), icon)

    if socketStatus[chosen] == 1:
        bashCommand = "sudo $HOME/utils/433Utils/RPi_utils/send" + " " + str(code) + " " + str(chosen) + " 0"
        subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
        xbmcgui.Dialog().notification('Socket ' + str(chosen) + ' off', 'Turned off socket ' + str(chosen), icon)

    del socketStatus[:]
    del socketList[:]
