This is a simple update program for Kodi.

It does nothing than keep all your programs up to date

============
Installation
============

Launch Kodi >> Add-ons >> Get More >> .. >> Install from zip file

If there is an error feel free to add an issue.
