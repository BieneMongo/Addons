import xbmcaddon
import xbmcgui
import xbmc

import subprocess

addon = xbmcaddon.Addon()
sockets = int(addon.getSetting('sockets'))

socketName = [addon.getSetting('s1'),
              addon.getSetting('s2'),
              addon.getSetting('s3'),
              addon.getSetting('s4'),
              addon.getSetting('s5'),
              addon.getSetting('s6'),
              addon.getSetting('s7'),
              addon.getSetting('s8'),
              addon.getSetting('s9')]

# Check if Sockets are defined
if sockets == 0:
    xbmcgui.Dialog().notification('Error: No sockets set', 'The number of sockets is not defined', xbmcgui.NOTIFICATION_ERROR)
    exit()
if sockets > 9:
    xbmcgui.Dialog().notification('Error: Too much sockets set', 'The number of sockets is not defined ' + str(sockets) + ' > 9', xbmcgui.NOTIFICATION_ERROR)
    exit()

addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')

profile = xbmc.translatePath(addon.getAddonInfo('profile')).decode("utf-8")
status = profile + "resources/status"

# Code for the remote
code = int(addon.getSetting('code'))

# Status for each socket
socketStatus = []
# Set default value to 0
currentSocket = 0
while currentSocket < sockets:
    socketStatus.append("0")
    currentSocket += 1

# Check if different status is set
try:
    # Open status file
    f = open(status, "r")
    line = 0

    # read every line
    for x in f:
        # check for 0 or 1 only
        if x[3] != "0" and x[3] != "1":
            # send notification, close file, exit
            xbmcgui.Dialog().notification('Error: Wrong Status', 'Some sockets may have wrong status: ' + x, xbmcgui.NOTIFICATION_ERROR)
            f.close()
            exit()

        # write last status to local variable
        socketStatus[line] = x[3]
    f.close()
except:
    # write config
    f = open(status, "a")
    currentSocket = 0
    while currentSocket < sockets:
        f.write(str(currentSocket) + str(socketStatus[currentSocket]) + '\n')
        currentSocket += 1
    f.close()

finally:
    # create an socket list
    socketList = []
    currentSocket = 0

    while currentSocket < sockets:

        defaultString = "Socket " + str(currentSocket+1)

        if socketName[currentSocket]:
            appendString = socketName[currentSocket]
        else:
            appendString = defaultString

        if socketStatus[currentSocket] == "0":
            socketList.append(appendString + " on")
        if socketStatus[currentSocket] == "1":
            socketList.append(appendString + " off")
        currentSocket += 1

    # create selection dialog
    chosen = xbmcgui.Dialog().select('Select the socket', socketList)

    # send on/off codes
    defaultString = "socket " + str(chosen + 1)

    if socketName[currentSocket]:
        appendString = socketName[chosen]
    else:
        appendString = defaultString

    if socketStatus[chosen] == "0":
        bashCommand = "sudo $HOME/utils/433Utils/RPi_utils/send" + " " + str(code) + " " + str(chosen) + " 1"
        subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
        xbmcgui.Dialog().notification('Socket ' + str(chosen) + ' on', 'Turned on ' + appendString, icon)

    if socketStatus[chosen] == "1":
        bashCommand = "sudo $HOME/utils/433Utils/RPi_utils/send" + " " + str(code) + " " + str(chosen) + " 0"
        subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
        xbmcgui.Dialog().notification('Socket ' + str(chosen) + ' off', 'Turned off ' + appendString, icon)

    # rewrite status file
    f = open(status, "a")
    currentSocket = 0
    while currentSocket < sockets:
        f.write(str(currentSocket) + str(socketStatus[currentSocket]) + '\n')
        currentSocket += 1
    f.close()

    del socketStatus[:]
    del socketList[:]
